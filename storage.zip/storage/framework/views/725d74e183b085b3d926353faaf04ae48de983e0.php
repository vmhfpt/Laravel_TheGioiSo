<?php $__env->startSection('content'); ?>
    <form method="POST" action=<?php echo e(route('atributePlatForm.add.submit')); ?>>

        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-warning">
                    <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
                </div>
            <?php endif; ?>
            <div class=" form-group">
                <label>Lựa chọn nền tảng:</label>
                <select name="platform" class="type-id form-control">
                    <option value="0">-- lựa chọn --</option>
                    <?php $__currentLoopData = $listPlatForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php if(Session::has('msg')): ?>
            <div class="alert alert-danger">
                <strong>Thất bại!</strong> <?php echo Session::get('msg'); ?>

            </div>
        <?php endif; ?>
            <div class="col-sm-6">

                <div class="form-group">
                    <label>Lựa chọn thuộc tính:</label>
                    <?php $__currentLoopData = $listType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-checkbox">
                            <input name="type[]" class="custom-control-input custom-control-input-danger" type="checkbox"
                                id="customCheckbox<?php echo e($key); ?>" value="<?php echo e($value->id); ?>">
                            <label for="customCheckbox<?php echo e($key); ?>" class="custom-control-label"><?php echo e($value->description); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                  </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Thêm</button>
        </div>
    </form>
    <script src="/template/admin/js/category/category.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/atribute/addTypePlatform.blade.php ENDPATH**/ ?>