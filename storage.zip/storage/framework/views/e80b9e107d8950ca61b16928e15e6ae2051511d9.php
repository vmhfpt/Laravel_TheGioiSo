<?php $__env->startSection('content'); ?>
    <form method="POST" action=<?php echo e(route('product.add.submit')); ?> enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-warning">
                    <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
                </div>
            <?php endif; ?>
            <div class="form-group">
                <label>Tên sản phẩm</label>
                <input value="<?php echo e(old('name')); ?>" name="name" type="text" class="form-control"
                    placeholder="Nhập tên sản phẩm">
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <label>Danh mục</label>
                <select name="category" class="form-control">
                    <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($value->id); ?>><?php echo e(Str_repeat('--', $value['lever'])); ?> <?php echo e($value->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div class="form-group">
                <label>Giá gốc</label>
                <input value="<?php echo e(old('price')); ?>" name="price" type="number" class="form-control"
                    placeholder="Nhập giá gốc sản phẩm">
            </div>
            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <label>Giá ưu đãi</label>
                <input value="<?php echo e(old('price_sale')); ?>" name="price_sale" type="number" class="form-control"
                    placeholder="Nhập giá ưu đãi sản phẩm">
            </div>
            <?php $__errorArgs = ['price_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <label>Mô tả</label>
                <input value="<?php echo e(old('description')); ?>" name="description" type="text" class="form-control"
                    placeholder="Nhập mô tả">
            </div>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



            <div class="form-group">
                <label>Nội dung</label>
                <textarea type="text" class="form-control" rows="5" id="content" name="content">  <?php echo e(old('content')); ?></textarea>

            </div>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <div class="custom-control custom-switch">
                    <input name="active" value="<?php echo e(old('active')); ?>" type="checkbox" class="custom-control-input"
                        id="customSwitch1">
                    <label class="custom-control-label" for="customSwitch1">Trạng thái kích hoạt</label>
                </div>
            </div>
            <div class="custom-file">

                <input accept="image/*" name="thumb[]" type="file" class="custom-file-input" id="customFile">
                <label class="custom-file-label" for="customFile">Chọn một ảnh đại diện sản phẩm</label>
            </div> <br /> <br />
            <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <strong>Lỗi !</strong> <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <img id="imgSrc" src="https://www.freeiconspng.com/thumbs/no-image-icon/no-image-icon-6.png"
                style="margin-top : 30px" class="rounded" width="304" height="236">
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    <script src="/template/admin/ckeditor/ckeditor.js"></script>
    <script src="/template/admin/js/color/color.js"></script>
    <script src="/template/admin/js/product/product.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/product/add.blade.php ENDPATH**/ ?>