<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th>STT</th>
      <th>Tiêu đề</th>
      <th>Ảnh</th>
      <th>Sản Phẩm</th>
      <th>Danh mục</th>
      <th>Ngày tạo</th>
      <th>Sửa</th>
      <th>Xóa</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($value->id); ?>">
            <td><?php echo e($key + 1); ?></td>
            <td> <?php echo e($value->title); ?>

            </td>
            <td> <img src="<?php echo e(url('storage/news/'.$value->thumb.'')); ?>" width="80" height="80"/>
            </td>
             <td> <?php echo e($value->getProduct->name); ?></td>
             <td> <?php echo e($value->getCategoryNews->name); ?></td>
            <td><?php echo e($value->created_at); ?></td>
            <td><a href="/admin/news/edit/<?php echo e($value->slug); ?>"> <button type="button" class="btn btn-primary">Sửa</button></a></td>
            <td><button onclick="deleteItemNews(<?php echo e($value->id); ?>, '/admin/news/delete', '<?php echo e($value->title); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
  <script src="/template/admin/js/news/news.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/news/list.blade.php ENDPATH**/ ?>