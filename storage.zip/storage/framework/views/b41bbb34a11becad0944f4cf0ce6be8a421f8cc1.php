<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th>STT</th>
      <th>Nền tảng</th>
      <th>Thuộc tính sản phẩm</th>
    </tr>
    </thead>
    <tbody >
        <?php $__currentLoopData = $listPlatForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
             <td> <?php echo e($key + 1); ?></td>
             <td> <?php echo e($value->name); ?></td>
            <td> <a href="/admin/atribute/show-detail/<?php echo e($value->slug); ?>"> <button type="button" class="btn btn-success">Xem thêm <?php echo e(count($value->getProductType)); ?> Thuộc tính</button></a></td>
             </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>

  <script src="/template/admin/js/type/type.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/atribute/listPlatForm.blade.php ENDPATH**/ ?>