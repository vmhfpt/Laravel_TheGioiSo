<thead>
    <tr>
        <th>STT</th>
        <th>Tên</th>
        <th>Ảnh</th>
        <th>Kiểu hiển thị</th>
        <th>Đánh dấu</th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($value->id); ?>">
            <td><?php echo e($key + 1); ?></td>
            <td> <?php echo e($value->name); ?>

            </td>
            <td> <img src="<?php echo e(url('storage/products/' . $value->thumb . '')); ?>" width="80" height="80" />
            </td>
            <td id="text<?php echo e($value->id); ?>"> <b> <?php
                    if ($value->view_model == 1) {
                        echo '<b>Mua nhiều nhất</b>';
                    }
                    if ($value->view_model == 2) {
                        echo '<b>Sản phẩm hót</b>';
                    }
                    if ($value->view_model == 3) {
                        echo '<b>sản phẩm bán chạy</b>';
                    }

            ?></b>
            <td id="change<?php echo e($value->id); ?>">
                <div class="custom-control custom-checkbox">
                    <input name="product[]" value=<?php echo e($value->id); ?> class="custom-control-input custom-control-input-danger product-checked" type="checkbox"
                        id="customCheckbox<?php echo e($key); ?>">
                    <label for="customCheckbox<?php echo e($key); ?>" class="custom-control-label" ></label>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/product/outputProductList.blade.php ENDPATH**/ ?>