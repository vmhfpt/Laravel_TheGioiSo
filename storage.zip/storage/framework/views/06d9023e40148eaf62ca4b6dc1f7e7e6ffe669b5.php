<?php $__env->startSection('content_post'); ?>
<?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="latest-post-area">
    <div class="container">
        <div class="area-title">
            <h2><?php echo e($category->name); ?></h2>
        </div>
        <div class="row">
            <div class="all-singlepost">
    <?php $__currentLoopData = $category->getNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-4 col-xs-12">
        <div class="single-post">
            <div class="post-thumb">
                <a href="/news/<?php echo e($news->slug); ?>">
                    <img src="<?php echo e(url('storage/news/'.$news->thumb.'')); ?>" alt="">
                </a>
            </div>
            <div class="post-thumb-info">
                <div class="post-time">
                    <a href="/news/<?php echo e($news->slug); ?>"><?php echo e($news->title); ?></a>

                </div>
                <div class="postexcerpt">
                    <p><?php echo e($news->description); ?>...</p>
                    <a href="/news/<?php echo e($news->slug); ?>" class="read-more">Đọc thêm</a>
                </div>
            </div>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--<div class="latest-post-area">
    <div class="container">
        <div class="area-title">
            <h2>Latest Post</h2>
        </div>
        <div class="row">
            <div class="all-singlepost">

                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="single-post">
                        <div class="post-thumb">
                            <a href="#">
                                <img src="img/post/post-1.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-thumb-info">
                            <div class="post-time">
                                <a href="#">Beauty</a>
                                <span>/</span>
                                <span>Post by</span>
                                <span>BootExperts</span>
                            </div>
                            <div class="postexcerpt">
                                <p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas...</p>
                                <a href="#" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="single-post">
                        <div class="post-thumb">
                            <a href="#">
                                <img src="img/post/post-2.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-thumb-info">
                            <div class="post-time">
                                <a href="#">Fashion</a>
                                <span>/</span>
                                <span>Post by</span>
                                <span>BootExperts</span>
                            </div>
                            <div class="postexcerpt">
                                <p>Fusce ac odio odio. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus...</p>
                                <a href="#" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="single-post">
                        <div class="post-thumb">
                            <a href="#">
                                <img src="img/post/post-3.jpg" alt="">
                            </a>
                        </div>
                        <div class="post-thumb-info">
                            <div class="post-time">
                                <a href="#">Brunch Network</a>
                                <span>/</span>
                                <span>Post by</span>
                                <span>BootExperts</span>
                            </div>
                            <div class="postexcerpt">
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt...</p>
                                <a href="#" class="read-more">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/news.blade.php ENDPATH**/ ?>