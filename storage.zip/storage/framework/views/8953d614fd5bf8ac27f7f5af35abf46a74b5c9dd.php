<?php
$total = 0;
$sumCart = 0;

foreach ($dataCart as $key => $value) {

    $sumCart = $sumCart + $value->quantity;
}

?>

<div class="shopping-carts text-right">
    <div class="cart-toggler">
        <a href="#"><i class="icon-bag"></i></a>


        <a href="#"><span class="cart-quantity"><?php echo e($sumCart); ?></span></a>
    </div>
    <div class="restrain small-cart-content">
        <ul class="cart-list">

            <?php $__currentLoopData = $dataCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a class="sm-cart-product" href="product-details.html">
                        <img src="<?php echo e(url('storage/library/' .$value->getColor->thumb. '')); ?>" alt="">
                    </a>
                    <div class="small-cart-detail">
                        <a data-delete="<?php echo e($value->getColor->id); ?>" class="remove" href="#"><i class="fa fa-times-circle"></i></a>

                        <a class="small-cart-name" href="product-details.html"><?php echo e($value->getColor->getProduct->name); ?></a>
                        <span
                            class="quantitys"><strong><?php echo e($value->quantity); ?></strong>x<span><?php echo e(number_format($value->getColor->price_sale, 0, '', '.')); ?>đ</span></span>
                    </div>
                </li>
                <?php
                    $total = $total + (int) $value->quantity * (int) $value->getColor->price_sale;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <p class="total">Tạm tính: <span
                class="amount"><?php echo e(number_format($total, 0, '', '.')); ?>đ</span>
        </p>
        <p class="buttons">
            <a href="/cart" class="button">Đi đến giỏ hàng</a>
        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/cart/outputCartAccrount.blade.php ENDPATH**/ ?>