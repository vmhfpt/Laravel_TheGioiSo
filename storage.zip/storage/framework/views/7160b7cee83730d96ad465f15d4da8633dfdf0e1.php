<?php $__env->startSection('content'); ?>
<form method="POST" action=<?php echo e(route('categoryNews.add.submit')); ?>>

    <?php echo csrf_field(); ?>
    <div class="card-body">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success">
            <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

          </div>
<?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
          </div>
    <?php endif; ?>
      <div class="form-group">
        <label >Tên danh mục</label>
        <input name="name" type="text" class="form-control"  placeholder="Nhập tên danh mục">
      </div>
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>


    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </form>
  <script src="/template/admin/js/category/category.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/categoryNews/add.blade.php ENDPATH**/ ?>