<?php $__env->startSection('content'); ?>
<form method="POST" action=<?php echo e(route('ship.add.submit')); ?>>

    <?php echo csrf_field(); ?>
    <div class="card-body">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success">
            <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

          </div>
<?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
          </div>
    <?php endif; ?>

<div class="form-group">
    <label>Tỉnh,Thành phố :</label>
    <select  name="city" class="city form-control">
        <option  value="null"> -- Lựa chọn --</option>
        <?php $__currentLoopData = $listCity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option  value="<?php echo e($key->matp); ?>"> <?php echo e($key->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
  <?php if(session('city')): ?>
  <div class="alert alert-danger">
    <strong>Lỗi !</strong>  <?php echo e(session('city')); ?>

  </div>
<?php endif; ?>

  <div id="result">
      <div class="form-group">
        <label>Quận, Huyện :</label>
        <select id="more-district" name="district" class="district form-control">
            <option  value="null"> -- Lựa chọn --</option>
        </select>
    </div>
    <div class="form-group">
        <label>Xã,phường,thị trấn :</label>
        <select id="more-wards" name="wards" class="form-control">
            <option  value="null"> -- Lựa chọn --</option>
        </select>
    </div>
</div>
    <div class="form-group">
        <label >Phí vận chuyển</label>
        <input name="price" type="number" class="form-control"  placeholder="Nhập phí vận chuyển">
      </div>
      <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </form>
  <script src="/template/admin/js/ship/ship.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/ship/add.blade.php ENDPATH**/ ?>