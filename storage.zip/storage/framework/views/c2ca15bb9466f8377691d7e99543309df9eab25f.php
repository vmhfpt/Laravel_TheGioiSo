
  <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr id="<?php echo e($value->id); ?>">
    <td><?php echo e($key + 1); ?></td>
    <td><?php echo e($value->name); ?></td>
    <td><?php for($i = 0; $i < $value->vote; $i ++): ?>
        <span class="fa fa-star checked-icon"></span>
    <?php endfor; ?></td>
    <td><?php echo e($value->content); ?></td>
    <td><?php echo e($value->created_at); ?></td>
    <td data-id="<?php echo e($value->id); ?>" class="dash-board-show"> <a class="btn btn-primary btn-sm" href="#">
        <i class="fas fa-folder">
        </i>
        Chi tiết
    </a></td>
    <td>
        <a  class="btn btn-danger btn-sm" href="javascript:deleteComment(<?php echo e($value->id); ?>, '/admin/comment/delete', '<?php echo e($value->name); ?>');">
            <i class="fas fa-trash">
            </i>
            Xóa
        </a>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/comment/outputRating.blade.php ENDPATH**/ ?>