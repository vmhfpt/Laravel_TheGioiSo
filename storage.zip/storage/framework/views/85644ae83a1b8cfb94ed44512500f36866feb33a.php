<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th>STT</th>
      <th>Tên Màu</th>
      <th>Số lượng</th>
      <th>Ảnh đại diện</th>
      <th>Giá gốc</th>
      <th>Giá ưu đãi</th>
      <th>Trạng thái</th>
      <th>Thư viện ảnh</th>
      <th>Sửa</th>
      <th>Xóa</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td> <?php echo e($value->name_color); ?>

            </td>
            <td> <?php echo e($value->quantity); ?> </td>
            <td> <img src="<?php echo e(url('storage/library/'.$value->thumb.'')); ?>" width="80" height="80"/>
            </td>
             <td><?php echo e($value->price); ?></td>
             <td><?php echo e($value->price_sale); ?></td>

<!--<td><?php echo $value->active == 1 ? '<span class="badge bg-primary">Kinh doanh</span>' : '<span class="badge bg-danger">Ngừng kinh doanh</span>'; ?></td> -->

             <td> <?php echo $value->active == 1 ? '<span class="badge bg-primary">Kinh doanh</span>' : ''; ?>

                <?php echo $value->active == 3 ? '<span class="badge bg-danger">Ngừng kinh doanh</span>' : ''; ?>

                <?php echo $value->active == 2 ? '<span class="badge bg-warning">Tạm hết hàng</span>' : ''; ?>

            </td>
            <td> <a href="/admin/color/library/<?php echo e($value->id); ?>"> <button type="button" class="btn btn-info">Xem</button></a></td>
            <td><a href="/admin/color/edit/<?php echo e($value->id); ?>"> <button type="button" class="btn btn-primary">Sửa</button></a></td>
            <td><button onclick="deleteItemProduct(<?php echo e($value->id); ?>, '/admin/product/delete', '<?php echo e($value->name); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
  <script src="/template/admin/js/color/color.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/color/detail.blade.php ENDPATH**/ ?>