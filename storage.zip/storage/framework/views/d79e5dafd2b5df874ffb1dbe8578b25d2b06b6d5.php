<!DOCTYPE html>
<html>
<head>
    <title>Xác thực đơn hàng</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>

   <h3> Mã OTP : <b><?php echo e($details['otp']); ?></b></h3>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/otp/sendMailOtp.blade.php ENDPATH**/ ?>