<div>
    <h1 style="color : red"> ajax</h1>
    <a class="ajax-complete-click" href="javascript:;"> Test Ajax complete</a>
</div>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/Ajax/test.blade.php ENDPATH**/ ?>