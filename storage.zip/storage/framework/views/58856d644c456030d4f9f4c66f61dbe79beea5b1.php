<div class="form-group">
    <label>Quận, Huyện :</label>
    <select id="more-district" name="district" class="district form-control">
        <?php $__currentLoopData = $dataItem->getDistrict; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->maqh); ?>"> <?php echo e($value->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>Xã,phường,thị trấn :</label>
    <select id="more-wards" name="wards" class="form-control">
        <?php $__currentLoopData = $dataItem->getDistrict()->first()->getWards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($value->xaid); ?>" > <?php echo e($value->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/ship/outputDistrict.blade.php ENDPATH**/ ?>