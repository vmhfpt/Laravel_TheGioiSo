<?php $__env->startSection('content'); ?>
<style>
    .custom-btn {
        margin-top : 12px;
    }
</style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <form method="POST" action=<?php echo e(route('config.add.submit', ['slug' => $dataItem->slug])); ?>>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

            </div>
        <?php endif; ?>
            <?php $__currentLoopData = $listProductType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dropdown dropend">
                    <button type="button" class="custom-btn btn btn-warning dropdown-toggle" data-bs-toggle="dropdown">
                        <?php echo e($value->getType->description); ?>

                    </button>
                    <div class="dropdown-menu">
                        <div class="form-group">
                         <center>    <label>Lựa chọn giá trị phù hợp cho thuộc tính <?php echo e($value->getType->description); ?></label></center>
                            <select multiple name="value[]" class="custom-select">
                                <?php $__currentLoopData = $value->getType->getValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($key == 0 ? 'selected' : ''); ?> value=<?php echo e($value->id); ?>><?php echo e($value->value); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Lưa lại</button>
        </div>
    </form>
    <script src="/template/admin/js/product/product.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/product/config.blade.php ENDPATH**/ ?>