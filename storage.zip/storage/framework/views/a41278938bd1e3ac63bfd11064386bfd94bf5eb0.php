<?php $__env->startSection('content_post'); ?>
    <style>
        .active-search {
            background: orange !important;
            color: white !important;
        }

        .pages button {
            background: orange;
            padding: 9px;
            border: none;
            color: white;
        }

        .select-color {
            color: red;
        }
        .price-init {
            text-decoration: line-through;
        }
    </style>




    <?php if($total == 0): ?>
        <div class="our-services-info">

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="f-title text-center">
                            <h3 class="title text-headss">Không tìm thấy sản phẩm nào</h3>
                        </div>
                    </div>
                </div><!-- End .row -->
                <div class="row text-center">
                    <div class="our-services-inner">
                        <div class="col-sm-4">
                            <div class="single-service">
                                <p><i class="fa fa-star"></i></p>
                                <h4>Kiểm tra lỗi chính tả của từ khóa đã nhập
                                </h4>

                            </div><!-- End .single-service -->
                        </div><!-- End .col-sm-4 -->
                        <div class="col-sm-4">
                            <div class="single-service">
                                <p><i class="fa fa-heart"></i></p>
                                <h4> Thử lại bằng từ khóa khác
                                </h4>

                            </div><!-- End .single-service -->
                        </div><!-- End .col-sm-4 -->
                        <div class="col-sm-4">
                            <div class="single-service">
                                <p><i class="fa fa-camera-retro"></i></p>
                                <h4> Thử lại bằng những từ khóa tổng quát hơn
                                </h4>

                            </div><!-- End .single-service -->
                        </div><!-- End .col-sm-4 -->
                    </div>
                    <div class="clearfix"></div>

                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="shop-with-sidebar">
            <div class="container">
                <div class="row">
                    <!-- left sidebar start -->

                    <!-- left sidebar end -->
                    <!-- right sidebar start -->
                    <div class="col-md-9 col-sm-12 col-xs-12">
                        <h3> Tìm thấy <?php echo e($total); ?> kết quả cho "<?php echo e($keyBoard); ?>"</h3>
                        <!-- shop toolbar start -->
                        <div class="shop-content-area">
                            <div class="shop-toolbar">
                                <div class="exp-tags">
                                    <div class="tags">

                                        <?php $__currentLoopData = $arrayResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a data-platform="<?php echo e($value['name']); ?>" class="search-more <?php echo e($activePlatForm == $key ? 'active-search' : ''); ?>"
                                                href="javascript:;"><?php echo e($value['name']); ?> (<?php echo e($value['quantity']); ?>)</a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <?php
                            $demo = 'lap';
                        ?>
                        <!-- shop toolbar end -->
                        <!-- product-row start -->
                        <div class="tab-content more-product-filter">
                            <div class="tab-pane fade in active" id="shop-grid-tab">
                                <div class="row">
                                    <div class="shop-product-tab first-sale ">
                                        <?php $__currentLoopData = $dataItem->where('name', $arrayResult[$activePlatForm]['name']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $value->getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $ct->getProduct()->where('name', 'LIKE', "%{$keyBoard}%")->take(9)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                                        <div class="two-product">

                                                            <div class="single-product">

                                                                <div class="product-img">
                                                                    <a href="#">
                                                                        <img class="primary-image"
                                                                            src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>"
                                                                            alt="">
                                                                        <img class="secondary-image"
                                                                            src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>"
                                                                            alt="">
                                                                    </a>
                                                                    <div class="action-zoom">
                                                                        <div class="add-to-cart">
                                                                            <a href="/<?php echo e($value->slug); ?>/<?php echo e($pr->slug); ?>"
                                                                                title="Quick View"><i
                                                                                    class="fa fa-search-plus"></i></a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="actions">
                                                                        <div class="select-color">
                                                                            <?php $__currentLoopData = $pr->getColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <input type="radio" class="form-check-input"
                                                                                    name="color_<?php echo e($pr->id); ?>"
                                                                                    value="<?php echo e($valueColor->id); ?>"><?php echo e($valueColor->name_color); ?>

                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                                        </div>
                                                                        <div class="action-buttons">
                                                                            <div class="add-to-links">
                                                                                <div class="add-to-wishlist">
                                                                                    <a href="#" title="Add to Wishlist"><i
                                                                                            class="fa fa-heart"></i></a>
                                                                                </div>
                                                                                <div data-product="<?php echo e($pr->id); ?>"
                                                                                    class="compare-button handle-cart">
                                                                                    <a href="javascript:;"
                                                                                        title="Add to Cart"><i
                                                                                            class="icon-bag"></i></a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="quickviewbtn">
                                                                                <a href="#" title="Add to Compare"><i
                                                                                        class="fa fa-retweet"></i></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="price-box">
                                                                        <span class="new-price"><?php echo e(number_format($pr->price_sale , 0, '', '.')); ?>Đ</span>
                                                                    </div>
                                                                </div>
                                                                <div class="product-content">
                                                                    <h2 class="product-name"><a href="#"><?php echo e($pr->name); ?></a>
                                                                    </h2>
                                                                    <h2 class="product-name price-init"><a
                                                                            href="#"><?php echo e(number_format($pr->price , 0, '', '.')); ?>Đ</a>
                                                                    </h2>
                                                                    <?php if($dataItem->where('name', $arrayResult[$activePlatForm]['name'])->first()->id == 1 && $dataItem->where('name', $arrayResult[$activePlatForm]['name'])->first()->id == 6): ?>
                                                                    <p>Ram:<?php echo e($pr->getProductValue()->where('type_id', 2)->first()->getValue->value); ?>,Rom:<?php echo e($pr->getProductValue()->where('type_id', 3)->first()->getValue->value); ?>,Chip:<?php echo e($pr->getProductValue()->where('type_id', 4)->first()->getValue->value); ?>,

                                                                        Pin:<?php echo e($pr->getProductValue()->where('type_id', 6)->first()->getValue->value); ?>


                                                                    </p>
                                                                    <?php endif; ?>

                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!-- -->


                                    </div>
                                </div>
                                <!-- product-row end -->
                                <!-- product-row start -->

                                <!-- product-row end -->
                            </div>
                            <!-- list view -->

                            <!-- shop toolbar start -->
                            <?php if($arrayResult[$activePlatForm]['quantity'] > 9): ?>
                                <div class="shop-content-bottom">
                                    <div class="shop-toolbar btn-tlbr">

                                        <div class="col-md-4 col-sm-4 col-xs-12 text-center">
                                            <div class="pages">

                                                <button data-page="2" class="pagination-more"> Xem thêm
                                                    <?php echo e($arrayResult[$activePlatForm]['quantity'] - 9); ?> sản
                                                    phẩm</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <!-- shop toolbar end -->
                        </div>
                    </div>
                    <!-- right sidebar end -->
                </div>
            </div>
        </div>
    <?php endif; ?>
    <script src="/template/post/js/home/home.js"></script>
    <script src="/template/post/js/search/search.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/resultSearch.blade.php ENDPATH**/ ?>