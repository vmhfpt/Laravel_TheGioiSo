<?php $__env->startSection('content'); ?>
<form method="POST" action=<?php echo e(route('color.update.submit',['id' => $name->id])); ?> enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <input type="hidden" name="product_id" value="<?php echo e($name->getProduct->id); ?>">
    <div class="card-body">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success">
            <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

          </div>
<?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
          </div>
    <?php endif; ?>
    <div class="form-group">
        <label >Tên màu</label>
        <input value="<?php echo e(old('name') ? old('name') : $name->name_color); ?>" name="name" type="text" class="form-control"  placeholder="VD : Màu Đỏ">
      </div>
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-group">
    <label >Giá gốc</label>
    <input value="<?php echo e(old('price') ? old('price') : $name->price); ?>" name="price" type="number" class="form-control"  placeholder="Nhập giá gốc sản phẩm">
  </div>
  <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="alert alert-danger">
      <strong>Lỗi !</strong> <?php echo e($message); ?>

    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="form-group">
<label >Giá ưu đãi</label>
<input value="<?php echo e(old('price_sale') ? old('price_sale') : $name->price_sale); ?>" name="price_sale" type="number" class="form-control"  placeholder="Nhập giá ưu đãi sản phẩm">
</div>
<?php $__errorArgs = ['price_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger">
  <strong>Lỗi !</strong> <?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="custom-file">
        <input accept="image/*" name="thumb[]"  type="file" class="custom-file-input" id="customFile">
        <label class="customFile custom-file-label" for="customFile">Chọn một ảnh đại diện sản phẩm</label>
      </div> <br/> <br/>
      <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <img id="imgSrc" src="<?php echo e(url('storage/library/'.$name->thumb.'')); ?>" style="margin-top : 30px" class="rounded"  width="304" height="236"><br/> <br/>
      <div class="form-group">
        <label >Chọn trạng thái</label>
        <div class="form-check">
            <input type="radio" class="form-check-input" id="radio1" name="active" value="1" <?php echo e($name->active == 1 ? 'checked' : ''); ?>>
            <label class="form-check-label" for="radio1">Kinh doanh</label>
          </div>
          <div class="form-check">
            <input type="radio" class="form-check-input" id="radio2" name="active" value="2" <?php echo e($name->active == 2 ? 'checked' : ''); ?>>
            <label class="form-check-label" for="radio2">Tạm hết hàng</label>
          </div>
          <div class="form-check">
            <input type="radio" class="form-check-input" id="radio3" name="active" value="3" <?php echo e($name->active == 3 ? 'checked' : ''); ?>>
            <label class="form-check-label">Ngừng kinh doanh</label>
          </div>
      </div>
      <div class="form-group">
        <label >Số lượng sản phẩm</label>
        <input value="<?php echo e(old('quantity') ? old('quantity') : $name->quantity); ?>" name="quantity" type="number" class="form-control"  placeholder="Nhập số lượng sản phẩm">
      </div>
      <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


      <div class="filter-container p-0 row">

      </div>

    </div>


    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </form>
  <script src="/template/admin/js/color/color.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/color/edit.blade.php ENDPATH**/ ?>