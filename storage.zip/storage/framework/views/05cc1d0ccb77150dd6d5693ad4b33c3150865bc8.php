<?php $__currentLoopData = $dataCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr id="delete-detail-<?php echo e($value->id); ?>">
    <td class="width-custom">
        <a href="#"><img src="<?php echo e(url('storage/library/' . $value->thumb . '')); ?>"
                class="img-responsive" alt="" /></a>
    </td>
    <td>
        <h6><?php echo e($value->getProduct->name); ?></h6>
    </td>
    <td><a href="#"><?php echo e($value->name_color); ?></a></td>
    <td>
        <div class="cart-price">
            <?php echo e(number_format($value->price_sale, 0, '', '.')); ?>đ </div>
    </td>
    <td class="width-custom-button">
            <button data-id="<?php echo e($value->id); ?>" id="prev" class="quantyti-button"> - </button>
            <input class="input-quantity" id="<?php echo e($value->id); ?>" type="number" value="<?php
            echo $arrayQuantity[$value->id];
        ?>">
         <button data-id="<?php echo e($value->id); ?>" id="next" class="quantyti-button"> + </button>
    </td>
    <td>
        <div class="cart-subtotal">
            <?php
                echo number_format($value->price_sale * $arrayQuantity[$value->id], 0, '', '.');
            ?>
            đ</div>
    </td>
    <td><a class="delete-cart" data-delete="<?php echo e($value->id); ?>" href="javascript:;"><i class="fa fa-times"></i></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/cart/outputDetailCart.blade.php ENDPATH**/ ?>