<?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="<?php echo e($value->getType->id); ?>">
    <td><?php echo e($key + 1); ?></td>
    <td><?php echo e($value->getType->name); ?>

    </td>
     <td><?php echo e($value->getType->description); ?></td>
    <td><?php echo e($value->getType->created_at); ?></td>
    <td><a href="/admin/atribute/edit/<?php echo e($value->getType->id); ?>"> <button type="button" class="btn btn-primary">Sửa</button></a></td>
    <td><button onclick="deleteItemAtribute(<?php echo e($value->getType->id); ?>, '/admin/atribute/delete', '<?php echo e($value->getType->description); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/atribute/outputType.blade.php ENDPATH**/ ?>