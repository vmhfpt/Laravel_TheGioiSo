<?php $__env->startSection('content'); ?>
<br/> <br/><div class="filter-container p-0 row">

  <?php $__currentLoopData = $dataItem->getLibraryColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div id=<?php echo e($value->id); ?> style="border : 1px solid black;" class="filtr-item col-sm-2" data-category="1" data-sort="white sample">
    <button  data-id="<?php echo e($value->id); ?>" type="submit" class="event-delete btn btn-primary">Xóa</button>
      <img src="<?php echo e(url('storage/library/'.$value->thumb.'')); ?>" class="img-fluid mb-2" alt="white sample"/>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <form method="POST" action=<?php echo e(route('library.add.submit', ['id' => $dataItem->id])); ?> enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <div class="card-body">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success">
            <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

          </div>
<?php endif; ?>
    <div class="custom-file">
        <input accept="image/*" name="library[]"  type="file" class="custom-file-input" id="uploadMultiple" multiple>
        <label class="custom-file-label multiple" for="uploadMultiple">Chọn nhiều nhất 12 ảnh làm thư viện cho sản phẩm</label>
      </div>
      <?php $__errorArgs = ['library'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <br/> <br/>
      <div class="filter-container custom-upload p-0 row">
      </div>
    </div>
    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Thêm vào thư viện</button>
    </div>
  </form>
  <script src="/template/admin/js/color/color.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/color/library.blade.php ENDPATH**/ ?>