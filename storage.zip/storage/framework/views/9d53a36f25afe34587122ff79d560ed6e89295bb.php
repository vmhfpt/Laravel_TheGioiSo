<div class="tab-pane fade in active" id="shop-grid-tab">
    <div class="row">
        <div class="shop-product-tab first-sale ">


            <?php $__currentLoopData = $dataItem->getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $ct->getProduct()->where('name', 'LIKE', "%{$keyBoard}%")->take($page * 9)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="two-product">

                            <div class="single-product">

                                <div class="product-img">
                                    <a href="#">
                                        <img class="primary-image"
                                            src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>" alt="">
                                        <img class="secondary-image"
                                            src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>" alt="">
                                    </a>
                                    <div class="action-zoom">
                                        <div class="add-to-cart">
                                            <a href="/<?php echo e($dataItem->slug); ?>/<?php echo e($pr->slug); ?>" title="Quick View"><i
                                                    class="fa fa-search-plus"></i></a>
                                        </div>
                                    </div>
                                    <div class="actions">
                                        <div class="select-color">
                                            <?php $__currentLoopData = $pr->getColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="radio" class="form-check-input"
                                                    name="color_<?php echo e($pr->id); ?>"
                                                    value="<?php echo e($valueColor->id); ?>"><?php echo e($valueColor->name_color); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </div>
                                        <div class="action-buttons">
                                            <div class="add-to-links">
                                                <div class="add-to-wishlist">
                                                    <a href="#" title="Add to Wishlist"><i
                                                            class="fa fa-heart"></i></a>
                                                </div>
                                                <div data-product="<?php echo e($pr->id); ?>"
                                                    class="compare-button handle-cart">
                                                    <a href="javascript:;" title="Add to Cart"><i
                                                            class="icon-bag"></i></a>
                                                </div>
                                            </div>
                                            <div class="quickviewbtn">
                                                <a href="#" title="Add to Compare"><i class="fa fa-retweet"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="price-box">
                                        <span
                                            class="new-price"><?php echo e(number_format($pr->price_sale, 0, '', '.')); ?>Đ</span>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h2 class="product-name"><a href="#"><?php echo e($pr->name); ?></a>
                                    </h2>
                                    <h2 class="product-name price-init"><a
                                            href="#"><?php echo e(number_format($pr->price, 0, '', '.')); ?>Đ</a>
                                    </h2>
                                    <?php if($dataItem->id == 1 || $dataItem->id == 6): ?>
                                        <p>Ram:<?php echo e($pr->getProductValue()->where('type_id', 2)->first()->getValue->value); ?>,Rom:<?php echo e($pr->getProductValue()->where('type_id', 3)->first()->getValue->value); ?>,Chip:<?php echo e($pr->getProductValue()->where('type_id', 4)->first()->getValue->value); ?>,

                                            Pin:<?php echo e($pr->getProductValue()->where('type_id', 6)->first()->getValue->value); ?>


                                        </p>
                                    <?php endif; ?>

                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
    <!-- product-row end -->
    <!-- product-row start -->

    <!-- product-row end -->
</div>
<!-- list view -->

<!-- shop toolbar start -->
<?php if($total - ( $page * 9) > 0): ?>
<div class="shop-content-bottom">
    <div class="shop-toolbar btn-tlbr">

        <div class="col-md-4 col-sm-4 col-xs-12 text-center">
            <div class="pages">

                <button data-page="<?php echo e($page + 1); ?>" class="pagination-more"> Xem thêm
                    <?php echo e($total - $page * 9); ?> sản
                    phẩm</button>
            </div>
        </div>

    </div>
</div>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/product/outputProductPlatFormSeacher.blade.php ENDPATH**/ ?>