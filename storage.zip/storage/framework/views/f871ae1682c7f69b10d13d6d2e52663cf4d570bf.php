<?php $__env->startSection('content'); ?>
<form method="POST" action=<?php echo e(route('news.update.submit',['slug' => $item->slug])); ?> enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <div class="card-body">
        <?php if(Session::has('success')): ?>

        <div class="alert alert-success">
            <strong>Thành công!</strong> <?php echo Session::get('success'); ?>

          </div>
<?php endif; ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-warning">
            <strong>Lỗi !</strong> Vui vòng kiểm tra lại biểu mẫu!
          </div>
    <?php endif; ?>
      <div class="form-group">
        <label >Tiêu đề</label>
        <input value="<?php echo e(old('title') ? old('title') : $item->title); ?>"  name="title" type="text" class="form-control"  placeholder="Nhập tiêu đề tin tức">
      </div>
      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <div class="form-group">
        <label>Danh mục tin</label>
        <select name="category_news" class="form-control">
            <?php $__currentLoopData = $listCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e($item->category_news_id == $value->id ? 'selected' : ''); ?> value=<?php echo e($value->id); ?>> <?php echo e($value->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

      </div>

      <div class="form-group">
        <label >Mô tả ngắn</label>
        <input value="<?php echo e(old('description') ? old('description') : $item->description); ?>"  name="description" type="text" class="form-control"  placeholder="Nhập mô tả ngắn tin tức">
      </div>
      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <div class="form-group">
        <label>Tin thuộc sản phẩm</label>
        <select name="product_id" class="form-control">
            <option value="0"> -- Lựa Chọn --</option>
            <?php $__currentLoopData = $listProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <option <?php echo e($item->product_id == $value->id ? 'selected' : ''); ?> value=<?php echo e($value->id); ?>> <?php echo e($value->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

      </div>

      <div class="form-group">
        <label >Nội dung</label>
        <textarea type = "text" class="form-control" rows="5" id="content" name="content">  <?php echo e(old('content') ? old('content') : $item->content); ?> </textarea>

      </div>
      <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <div class="custom-file">

        <input accept="image/*" name="thumb[]"  type="file" class="custom-file-input" id="customFile">
        <label class="custom-file-label" for="customFile">Chọn một ảnh đại diện sản phẩm</label>
      </div> <br/> <br/>
      <?php $__errorArgs = ['thumb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
     <div class="alert alert-danger">
          <strong>Lỗi !</strong> <?php echo e($message); ?>

        </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <img id="imgSrc" src="<?php echo e(url('storage/news/'.$item->thumb.'')); ?>" style="margin-top : 30px" class="rounded"  width="304" height="236">
    </div>
    <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </form>
  <script src="/template/admin/ckeditor/ckeditor.js"></script>
  <script src="/template/admin/js/color/color.js"></script>
  <script src="/template/admin/js/product/product.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>