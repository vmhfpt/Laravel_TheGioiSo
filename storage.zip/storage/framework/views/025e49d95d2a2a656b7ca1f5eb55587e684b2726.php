<?php $__env->startSection('content_post'); ?>
<style>
     .select-color {
    color : red;
}
</style>
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="container-inner">
                        <ul>
                            <li class="home">
                                <a href="index.html">Tin tức</a>
                                <span><i class="fa fa-angle-right"></i></span>
                            </li>
                            <li class="category3"><span><?php echo e($dataItem->title); ?></span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="home-hello-info">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="f-title text-center">
                        <h3 class="title text-uppercase"><?php echo e($dataItem->title); ?></h3>
                    </div>
                    <h5><?php echo e($dataItem->description); ?></h5>
                </div>
            </div>
            <div class="row">

                    <div style=" text-align: center !important" class="about-page-cntent">
                        <?php echo $dataItem->content; ?>

                    </div>


            </div>
        </div>
    </div>
    <div class="our-product-area new-product">
        <div class="container">
            <div class="area-title">
                <h2>Sản phẩm liên quan</h2>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <?php $__currentLoopData = $dataPlatForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="features-curosel">
                                <?php $__currentLoopData = $value->getProduct()->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-12 col-md-12">
                                        <div class="single-product first-sale">
                                            <div class="product-img">
                                                <a href="javascript:;">
                                                    <img class="primary-image" src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>" alt="" />
                                                    <img class="secondary-image" src="<?php echo e(url('storage/products/' . $pr->thumb . '')); ?>" alt="" />
                                                </a>
                                                <div class="action-zoom">
                                                    <div class="add-to-cart">
                                                        <a href="/<?php echo e($value->slug); ?>/<?php echo e($pr->slug); ?>" title="Quick View"><i class="fa fa-search-plus"></i></a>
                                                    </div>
                                                </div>
                                                <div class="actions">
                                                    <div class="select-color">
                                                        <?php $__currentLoopData = $pr->getColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <input type="radio" class="form-check-input"
                                                                name="color_<?php echo e($pr->id); ?>"
                                                                value="<?php echo e($valueColor->id); ?>"><?php echo e($valueColor->name_color); ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </div>
                                                    <div class="action-buttons">
                                                        <div class="add-to-links">
                                                            <div class="add-to-wishlist">
                                                                <a href="#" title="Add to Wishlist"><i
                                                                        class="fa fa-heart"></i></a>
                                                            </div>
                                                            <div data-product="<?php echo e($pr->id); ?>"
                                                                class="compare-button handle-cart">
                                                                <a href="javascript:;" title="Add to Cart"><i
                                                                        class="icon-bag"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="quickviewbtn">
                                                            <a href="#" title="Add to Compare"><i
                                                                    class="fa fa-retweet"></i></a>
                                                        </div>
                                                    </div>
                                                </div>



                                                <div class="price-box">
                                                    <span class="new-price"><?php echo e(number_format($pr->price_sale, 0, '', '.')); ?>Đ</span>
                                                </div>
                                            </div>
                                            <div class="product-content">
                                                <h2 class="product-name"><a href="/<?php echo e($value->slug); ?>/<?php echo e($pr->slug); ?>"><?php echo e($pr->name); ?></a></h2>
                                                <p><?php echo e($value->name); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                    </div>
                </div>
            </div>

        </div>
    </div>
    <script src="/template/post/js/home/home.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/detailNew.blade.php ENDPATH**/ ?>