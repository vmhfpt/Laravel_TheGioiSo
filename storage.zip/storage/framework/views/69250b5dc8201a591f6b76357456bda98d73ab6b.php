<?php $__env->startSection('content'); ?>

<table id="example2" class="table table-bordered table-hover">
    <div  class=" form-group">
        <label>Lọc theo</label>
        <select name="type_id" class="type-id form-control">
          <?php $__currentLoopData = $dataAtribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($value->id); ?>" ><?php echo e($value->description); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    <thead>
    <tr>
      <th>STT</th>
      <th>Thuộc tính</th>
      <th>Giá trị</th>
      <th>Ngày tạo</th>

      <th>Xóa</th>
    </tr>
    </thead>
    <tbody id="result">
        <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($value->id); ?>">
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($value->getAtribute->description); ?>

            </td>
            <td><?php echo e($value->value); ?>

            </td>
            <td><?php echo e($value->created_at); ?></td>

            <td><button onclick="deleteItemValue(<?php echo e($value->id); ?>, '/admin/value-atribute/delete', '<?php echo e($value->value); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
  <script src="/template/admin/js/value/value.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/values/list.blade.php ENDPATH**/ ?>