<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">

    <thead>
    <tr>
      <th>STT</th>
      <th>Thuộc tính (biến thể sản phẩm)</th>
      <th>Ngày tạo</th>
      <th>Gỡ</th>
    </tr>
    </thead>
    <tbody id="result">
       <?php $__currentLoopData = $dataItem->getProductType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($value->id); ?>">
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($value->getType->description); ?>

            </td>
            <td><?php echo e($value->created_at); ?></td>
            <td><button onclick="deleteItemDetail(<?php echo e($value->id); ?>, '/admin/atribute/delete-detail', '<?php echo e($value->getType->description); ?>')" type="button" class="btn btn-danger">Gỡ</button></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

  </table>
  <a href="/admin/atribute/add-type"> <button type="button" class="btn btn-warning">Thêm thuộc tính cho nền tảng</button></a>
  <script src="/template/admin/js/type/type.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/atribute/detail.blade.php ENDPATH**/ ?>