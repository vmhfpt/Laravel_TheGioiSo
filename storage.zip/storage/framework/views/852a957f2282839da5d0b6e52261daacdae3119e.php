<?php $__env->startSection('content_post'); ?>
    <style>
        .price-init {
            text-decoration: line-through;
        }

        .select-color {
            color: red;
        }

        .show-select {
            border: 1px solid red !important;
        }

        .show-result button {
            background: orange;
            padding: 9px;
            border: none;
            color: white;
        }

        .pages button {
            background: orange;
            padding: 9px;
            border: none;
            color: white;
        }

    </style>
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="container-inner">
                        <ul>
                            <li class="home">
                                <a href="index.html">Home</a>
                                <span><i class="fa fa-angle-right"></i></span>
                            </li>
                            <li class="category3"><span><?php echo e($dataPlatForm->name); ?></span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shop-with-sidebar">
        <div class="container">
            <div class="row">
                <!-- left sidebar start -->
                <div class="col-md-3 col-sm-12 col-xs-12 text-left">
                    <div class="topbar-left">
                        <aside class="widge-topbar">
                            <div class="bar-title">
                                <div class="bar-ping"><img src="img/bar-ping.png" alt=""></div>
                                <h2>Bộ lọc</h2>
                            </div>
                        </aside>


                        <aside class="sidebar-content">
                            <div class="sidebar-title">
                                <h6>Đã chọn</h6>
                            </div>
                            <div class="exp-tags">
                                <div class="tags show-delete">

                                    <!--- show select user-->
                                    <!--  <a data-delete="" href="javascript:;">SamSung &times;</a>-->


                                </div>
                            </div>
                        </aside>
                        <div style="clear:both"></div>
                        <aside class="sidebar-content">
                            <div class="sidebar-title">
                                <h6>Danh mục</h6>
                            </div>
                            <div class="exp-tags">
                                <div class="tags">

                                    <?php $__currentLoopData = $dataPlatForm->getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="filter-category" data-filter="<?php echo e($value->id); ?>"
                                            href="javascript:;"><?php echo e($value->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </aside>



                        <?php $__currentLoopData = $dataPlatForm->getProductType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($type->getType->id == 2 || $type->getType->id == 3): ?>
                                <div style="clear:both"></div>
                                <aside class="sidebar-content">
                                    <div class="sidebar-title">
                                        <h6><?php echo e($type->getType->description); ?></h6>
                                    </div>
                                    <div class="exp-tags">
                                        <div class="tags">

                                            <?php $__currentLoopData = $type->getType->getValue()->orderBy('value', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($value->value != 'Chưa xác định'): ?>
                                                    <a data-filter="<?php echo e($value->id); ?>"
                                                        class="filter-<?php echo e($type->getType->name); ?>"
                                                        href="javascript:;"><?php echo e($value->value); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </aside>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--<aside class="sidebar-content">
                                                <div class="sidebar-title">
                                                    <h6>Ram</h6>
                                                </div>
                                                <div class="exp-tags">
                                                    <div class="tags">
                                                        <a data-filter="2" class="filter-price" href="javascript:;">2 Gb</a>
                                                        <a data-filter="3" class="filter-ram" href="javascript:;">3 Gb</a>
                                                        <a data-filter="4" class="filter-ram" href="javascript:;">4 Gb</a>
                                                        <a data-filter="8" class="filter-ram" href="javascript:;">8 Gb</a>
                                                        <a data-filter="12" class="filter-ram" href="javascript:;">12 Gb</a>
                                                    </div>
                                                </div>
                                            </aside>-->
                        <!--      <div style="clear:both"></div>
                                        <aside class="sidebar-content">
                                            <div class="sidebar-title">
                                                <h6>Bộ nhớ trong</h6>
                                            </div>
                                            <div class="exp-tags">
                                                <div class="tags">
                                                    <a href="#">8 Gb</a>
                                                    <a href="#">16 Gb</a>
                                                    <a href="#">32 Gb</a>
                                                    <a href="#">64 Gb</a>
                                                    <a href="#">128 Gb</a>
                                                    <a href="#">256 Gb</a>
                                                    <a href="#">512 Gb</a>

                                                </div>
                                            </div>
                                        </aside>-->
                        <div style="clear:both"></div>
                        <aside class="sidebar-content">
                            <div class="sidebar-title">
                                <h6>Giá</h6>
                            </div>
                            <div class="exp-tags">
                                <div class="tags">
                                    <a data-filter="1" class="filter-price" href="javascript:;">Dưới 2 triệu</a>
                                    <a data-filter="2" class="filter-price" href="javascript:;">Từ 2 - 4 triệu</a>
                                    <a data-filter="3" class="filter-price" href="javascript:;">Từ 4 - 7 triệu</a>
                                    <a data-filter="4" class="filter-price" href="javascript:;">Từ 7 - 13 triệu</a>
                                    <a data-filter="5" class="filter-price" href="javascript:;">Từ 13 - 20 triệu</a>
                                    <a data-filter="6" class="filter-price" href="javascript:;">Trên 20 triệu</a>

                                </div>
                            </div>
                        </aside>
                        <div style="clear:both"></div>
                        <div class="show-result">
                            <button class="ajax-quantity-show"> Xem </button>
                        </div>


                    </div>
                </div>
                <!-- left sidebar end -->
                <!-- right sidebar start -->
                <div class="col-md-9 col-sm-12 col-xs-12">
                    <!-- shop toolbar start -->
                    <div class="shop-content-area">
                        <div class="shop-toolbar">
                            <div class="col-md-4 col-sm-4 col-xs-12 nopadding-left text-left">
                                <form class="tree-most" method="get">
                                    <div class="orderby-wrapper">
                                        <label>Sắp xếp</label>
                                        <select name="orderby" class="orderby">
                                            <option value="asc" selected="selected">Giá tăng dần</option>
                                            <option value="desc">Giá giảm dần</option>
                                            <!--   <option value="rating">Sản phẩm hót</option>
                                                    <option value="date">Mua nhiều nhất</option>
                                                    <option value="price">Bán chạy</option>-->

                                        </select>
                                    </div>
                                </form>
                            </div>


                        </div>
                    </div>
                    <!-- shop toolbar end -->
                    <!-- product-row start -->
                    <div class="tab-content more-product-filter">
                        <div class="tab-pane fade in active" id="shop-grid-tab">
                            <div class="row">
                                <div class="shop-product-tab first-sale ">
                                    <?php $__currentLoopData = $dataFilter->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                            <div class="two-product">
                                                <!-- single-product start -->
                                                <div class="single-product">

                                                    <div class="product-img">
                                                        <a href="javascript:;">
                                                            <img class="primary-image"
                                                                src="<?php echo e(url('storage/products/' . $value->thumb . '')); ?>"
                                                                alt="">
                                                            <img class="secondary-image"
                                                                src="<?php echo e(url('storage/products/' . $value->thumb . '')); ?>"
                                                                alt="">
                                                        </a>
                                                        <div class="action-zoom">
                                                            <div class="add-to-cart">
                                                                <a href="/<?php echo e($dataPlatForm->slug); ?>/<?php echo e($value->slug); ?>"
                                                                    title="Quick View"><i class="fa fa-search-plus"></i></a>
                                                            </div>
                                                        </div>
                                                        <div class="actions">
                                                            <div class="select-color">
                                                                <?php $__currentLoopData = $value->getColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <input type="radio" class="form-check-input"
                                                                        name="color_<?php echo e($value->id); ?>"
                                                                        value="<?php echo e($valueColor->id); ?>"><?php echo e($valueColor->name_color); ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                            </div>
                                                            <div class="action-buttons">
                                                                <div class="add-to-links">
                                                                    <div class="add-to-wishlist">
                                                                        <a href="#" title="Add to Wishlist"><i
                                                                                class="fa fa-heart"></i></a>
                                                                    </div>
                                                                    <div data-product="<?php echo e($value->id); ?>"
                                                                        class="compare-button handle-cart">
                                                                        <a href="javascript:;" title="Add to Cart"><i
                                                                                class="icon-bag"></i></a>
                                                                    </div>
                                                                </div>
                                                                <div class="quickviewbtn">
                                                                    <a href="#" title="Add to Compare"><i
                                                                            class="fa fa-retweet"></i></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="price-box">
                                                            <span
                                                                class="new-price"><?php echo e(number_format($value->price_sale, 0, '', '.')); ?>Đ</span>
                                                        </div>
                                                    </div>
                                                    <div class="product-content">
                                                        <h2 class="product-name"><a href="#"><?php echo e($value->name); ?></a>
                                                        </h2>
                                                        <h2 class="product-name price-init"><a
                                                                href="#"><?php echo e(number_format($value->price, 0, '', '.')); ?>Đ</a>
                                                        </h2>
                                                        <?php if($dataPlatForm->id == 1 || $dataPlatForm->id == 6): ?>
                                                        <p>Ram:<?php echo e($value->getProductValue()->where('type_id', 2)->first()->getValue->value); ?>,Rom:<?php echo e($value->getProductValue()->where('type_id', 3)->first()->getValue->value); ?>,Chip:<?php echo e($value->getProductValue()->where('type_id', 4)->first()->getValue->value); ?>,

                                                            Pin:<?php echo e($value->getProductValue()->where('type_id', 6)->first()->getValue->value); ?>


                                                        </p>
                                                        <?php endif; ?>

                                                    </div>
                                                </div>
                                                <!-- single-product end -->
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                            <!-- product-row end -->
                            <!-- product-row start -->

                            <!-- product-row end -->
                        </div>
                        <!-- list view -->

                        <!-- shop toolbar start -->
                        <?php if($sumTotal - count($dataFilter->get()) > 0): ?>
                        <div class="shop-content-bottom">
                            <div class="shop-toolbar btn-tlbr">

                                <div class="col-md-4 col-sm-4 col-xs-12 text-center">
                                    <div class="pages">

                                        <button data-page="<?php echo e($page + 1); ?>" class="pagination-more"> Xem thêm
                                            <?php echo e($sumTotal - count($dataFilter->get())); ?> sản
                                            phẩm</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endif; ?>
                        <!-- shop toolbar end -->
                    </div>
                </div>
                <!-- right sidebar end -->
            </div>
        </div>
    </div>
    <script src="/template/post/js/home/home.js"></script>
    <script src="/template/post/js/detailplatform/detail.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/platForm.blade.php ENDPATH**/ ?>