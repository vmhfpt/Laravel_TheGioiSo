<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <div  class=" form-group">
        <label>Lọc theo nền tảng :</label>
        <select name="type_id" class="filter-platform form-control">
          <?php $__currentLoopData = $dataPlatForm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($value->id); ?>" ><?php echo e($value->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    <thead>
    <tr>
      <th>STT</th>
      <th>Tên</th>
      <th>Mô tả</th>
      <th>Ngày tạo</th>
      <th>Sửa</th>
      <th>Xóa</th>
    </tr>
    </thead>
    <tbody id="result">
        <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="<?php echo e($value->id); ?>">
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($value->name); ?>

            </td>
             <td><?php echo e($value->description); ?></td>
            <td><?php echo e($value->created_at); ?></td>
            <td><a href="/admin/atribute/edit/<?php echo e($value->id); ?>"> <button type="button" class="btn btn-primary">Sửa</button></a></td>
            <td><button onclick="deleteItemAtribute(<?php echo e($value->id); ?>, '/admin/atribute/delete', '<?php echo e($value->description); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

  </table>

  <script src="/template/admin/js/type/type.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/atribute/list.blade.php ENDPATH**/ ?>