<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th>STT</th>
      <th>Tên</th>
      <th>SĐT</th>
      <th>Địa chỉ</th>
      <th>Tổng</th>
      <th>Trạng thái</th>
      <th>Ngày đặt</th>
      <th>Chi tiết</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($key + 1); ?></td>
          <td><?php echo e($value->name); ?></td>
          <td><?php echo e($value->phone_number); ?></td>
          <td><?php echo e($value->address_detail); ?></td>
          <td>  <?php echo e(number_format($value->total, 0, '', '.')); ?>VNĐ</td>
          <td><?php
              if($value->active == 0){
                  echo '<span class="badge badge-danger">Chưa tiếp nhận</span>';
              }
              if($value->active == 1){
                  echo '<span class="badge badge-warning">Đã tiếp nhận</span>';
              }
              if($value->active == 2){
                  echo '<span class="badge badge-secondary">Đã xuất kho</span>';
              }
              if($value->active == 3){
                  echo '<span class="badge badge-info">Đang di chuyển</span>';
              }
              if($value->active == 4){
                  echo '<span class="badge badge-primary">Đã đến nơi</span>';
              }
              if($value->active == 5){
                  echo '<span class="badge badge-success">Hoàn thành</span>';
              }
              if($value->active == 6){
                  echo '<span class="badge badge-dark">Đã hủy</span>';
              }
          ?></td>
          <td>
            <div class="sparkbar" ><?php echo e($value->updated_at); ?></div>
          </td>
          <td><a href="/admin/oder/detail/<?php echo e($value->id); ?>" class="btn btn-info"><i class="fas fa-eye"></i></a></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/oder/list.blade.php ENDPATH**/ ?>