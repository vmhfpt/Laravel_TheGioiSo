<span> Sản phẩm gợi ý</span>
<ul class="list-auto-complete">
    <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/<?php echo e($value->getCategory->getBusiness->slug); ?>/<?php echo e($value->slug); ?>">
        <li>

            <img width="65" height="65"
                src="<?php echo e(url('storage/products/'.$value->thumb.'')); ?>">
            <h6> <?php echo e($value->name); ?></h6><br /><br />
            <b> <?php echo e(number_format($value->price_sale , 0, '', '.')); ?>đ </b> <strong>  <?php echo e(number_format($value->price , 0, '', '.')); ?>đ</strong>
            <div style="clear:both"> </div>
        </li>

    </a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/post/product/outputProductSearch.blade.php ENDPATH**/ ?>