<?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="<?php echo e($value->id); ?>">
    <td><?php echo e($key + 1); ?></td>
    <td><?php echo e($value->getAtribute->description); ?>

    </td>
    <td><?php echo e($value->value); ?>

    </td>
    <td><?php echo e($value->created_at); ?></td>

    <td><button onclick="deleteItemValue(<?php echo e($value->id); ?>, '/admin/value-atribute/delete', '<?php echo e($value->value); ?>')" type="button" class="btn btn-danger">Xóa</button></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/values/outputvalue.blade.php ENDPATH**/ ?>