<?php $__env->startSection('content'); ?>
<table id="example2" class="table table-bordered table-hover">
    <thead>
    <tr>
      <th>STT</th>
      <th>Tên</th>
      <th>Hình ảnh</th>
      <th>Tổng màu sắc</th>
      <th>Tổng số lượng</th>
      <th></th>
      <th>Chi tiết</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td> <?php echo e($value->name); ?>

            </td>
            <td> <img src="<?php echo e(url('storage/products/'.$value->thumb.'')); ?>" width="80" height="80"/>
            </td>
             <td><?php echo e(count($value->getColor)); ?> màu sắc</td>
            <td><?php echo e($value->getColor->sum('quantity')); ?> sản phẩm</td>
            <td><a href="/admin/color/add/<?php echo e($value->id); ?>"> <button type="button" class="btn btn-success">Thêm màu sắc</button></a></td>
            <td><a href="/admin/color/detail/<?php echo e($value->id); ?>"> <button type="button" class="btn btn-primary">Chi tiết</button></a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/color/list.blade.php ENDPATH**/ ?>