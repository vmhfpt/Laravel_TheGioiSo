<section class="content custom-show-more">
    <a href="javascript:;" class="close-comment close-custom"> &times;</a>

    <table id="example2" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th>STT</th>
          <th>Tên</th>
          <th>SĐT</th>
          <th>Nội dung</th>
          <th>Ngày post</th>
          <th></th>
          <th></th>
        </tr>
        </thead>
        <tbody>
       <?php $__currentLoopData = $dataItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


       <tr id="<?php echo e($value->id); ?>" >
        <td><?php echo e($key + 1); ?></td>
        <td><?php echo e($value->name); ?>

        </td>
        <td><?php echo e($value->number_phone); ?></td>
        <td><?php echo e($value->content); ?></td>
        <td><?php echo e($value->created_at); ?></td>
        <td data-id="<?php echo e($value->id); ?>" class="dash-board-show"> <a class="btn btn-primary btn-sm" href="#">
            <i class="fas fa-folder">
            </i>
            Chi tiết
        </a></td>
        <td>
            <a  onclick="deleteComment(<?php echo e($value->id); ?>, '/admin/comment/delete', '<?php echo e($value->name); ?>')" class="btn btn-danger btn-sm" href="javascript:;">
                <i class="fas fa-trash">
                </i>
                Xóa
            </a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

  </section>
<?php /**PATH C:\xampp\htdocs\Banhang\laravel\resources\views/admin/comment/outputCommentChildren.blade.php ENDPATH**/ ?>