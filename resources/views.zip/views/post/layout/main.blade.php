@include('post.layout.header')
@yield('content_post')
@include('post.layout.footer')
